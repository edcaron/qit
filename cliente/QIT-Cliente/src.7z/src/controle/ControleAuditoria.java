/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import dao.AuditoriaDAO;
import java.util.ArrayList;
import java.util.Date;
import modelo.Auditoria;
import modelo.Usuario;

/**
 *
 * @author Tiago
 */
public class ControleAuditoria {

    private AuditoriaDAO dao;

    public ControleAuditoria() {
        this.dao = new AuditoriaDAO();
    }

    public ArrayList<Auditoria> consultar(Date datainicial, Date datafinal, String tabela, char operacao, Usuario usuario) {
        System.out.println("cheguei no controle consultar auditoria");
        try {

            return dao.listar(datainicial, datafinal, tabela, operacao, usuario);
        } catch (Exception e) {

            System.out.println("erro no controle auditoria : " + e);
        }

        return null;
    }
}
