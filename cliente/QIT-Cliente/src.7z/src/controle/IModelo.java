/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author eduar_000
 */
public interface IModelo {
    
    public int getId();
    public String getNome();
    public void setNome(String nome);        
    
}
