/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controle.HibernateUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import modelo.Auditoria;
import modelo.Usuario;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 *
 * @author Tiago
 */
public class AuditoriaDAO {

    private Session sessao = null;

    public ArrayList<Auditoria> listar(Date datainicial, Date datafinal, String tabela, char operacao, Usuario usuario) {
        System.out.println("cheguei no listar");
        List resultado = null;

        ArrayList<Auditoria> lista = new ArrayList<>();
        try {
            System.out.println("data inicial" + datainicial.getDate());
            sessao = HibernateUtil.getSessionFactory().openSession();
            sessao.beginTransaction();
            String sql = "from Permissao p where lower(p.tablea) like lower('%" + tabela + "%') "
                    + "and lower(p.operacao) like lower('%" + operacao + "%') "
                    + "and p.dt > " + datainicial + ""
                    + "and p.dt < " + datafinal + ""
                    + " order by p.id ";
            System.out.println("a query e " + sql);
            org.hibernate.Query q = sessao.createQuery(sql);
            resultado = q.list();

            for (Object o : resultado) {
                Auditoria s = ((Auditoria) ((Object) o));
                lista.add(s);
            }

        } catch (HibernateException he) {
            System.out.println("Erro na consulta de auditoria " + he.getCause());
            he.printStackTrace();
        } finally {
            sessao.close();
        }
        return lista;
    }

    //se o campo for do dateTime, ou TimesTamp para poder "ignonar" a hh:mm:ss   
    public List<Auditoria> buscarPorData(Date dataIni, Date dataFim) {//pode passar a mesma data para os dois parametro.  

        Calendar periodoInicial = Calendar.getInstance();
        Calendar periodoFinal = Calendar.getInstance();

        periodoInicial.setTime(dataIni);
        periodoFinal.setTime(dataFim);

        //zerando hora do periodo inicial         
        periodoInicial.set(Calendar.HOUR_OF_DAY, 0);
        periodoInicial.set(Calendar.MINUTE, 0);
        periodoInicial.set(Calendar.SECOND, 0);

        //inicializando hora do peridoFinal  
        periodoFinal.set(Calendar.HOUR_OF_DAY, 23);
        periodoFinal.set(Calendar.MINUTE, 59);
        periodoFinal.set(Calendar.SECOND, 59);
return null;//apagar
//        Query q = session.createQuery("SELECT a FROM Classe a WHERE a.beanData BETWEEN ? AND ?  ");
//        q.setParameter(0, periodoInicial.getTime());
//        q.setParameter(1, periodoFinal.getTime());
//        return q.list();
//
//        //agora se o seu campo nao armazena hh:mm:ss   
//        //vc usa o mesmo metod sem precisar usar o Calendar. basta fazer assim  
//        String sql = ("SELECT a FROM Classe a WHERE a.beanData BETWEEN ? AND ?  ");
//        org.hibernate.Query q = sessao.createQuery(sql);
//        q = session.createQuery;
//        q.setParameter(0, dataIni;
//        q.setParameter(1, dataFim);
//    }
    }
}
